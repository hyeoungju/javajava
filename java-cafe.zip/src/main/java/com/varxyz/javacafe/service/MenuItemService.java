package com.varxyz.javacafe.service;

import com.varxyz.javacafe.domain.MenuItem;

public interface MenuItemService {
	public void addMenuItem(MenuItem menuItem);
}
