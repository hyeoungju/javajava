package com.varxyz.javacafe.domain;

public class Cart {
	
}
