package com.varxyz.javacafe.domain;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class MenuItem {
	private long lcId;
	private long scId;
	private long mId;
	private String menuName;
	private double menuPrice;
	private long menuImg;
	private Date regDate;
}
