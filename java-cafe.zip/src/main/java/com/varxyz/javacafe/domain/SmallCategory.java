package com.varxyz.javacafe.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SmallCategory {
	private long scId;
	private long lcId;
	private String scName;
}
