CREATE TABLE MenuItem (
	


)