package com.varxyz.jvx330.di.example5.ex2;

public class SessionCartService implements CartService{

	public void addItem() {
		System.out.println("SessionCartService : addItem() is called");
	}
}
