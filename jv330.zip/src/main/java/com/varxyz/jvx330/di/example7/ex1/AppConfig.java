package com.varxyz.jvx330.di.example7.ex1;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = {"com.varxyz.jvx330.di.example7.ex1"})
public class AppConfig {
	
}
