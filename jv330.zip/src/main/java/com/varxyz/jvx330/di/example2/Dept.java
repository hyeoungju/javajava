package com.varxyz.jvx330.di.example2;


//getter,setter
public class Dept {
	private String deptName;
	private String deptAddr;
	
	public String getDeptName() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getDeptAddr() {
		return deptAddr;
	}

	public void setDeptAddr(String deptAddr) {
		this.deptAddr = deptAddr;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
	
	
}
