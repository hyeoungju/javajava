package com.varxyz.jvx330.di.example5.ex1;

public interface MemberService {
	void addMember(String id, String passwd);
}
