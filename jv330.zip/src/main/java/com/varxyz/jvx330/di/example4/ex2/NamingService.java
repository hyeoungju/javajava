package com.varxyz.jvx330.di.example4.ex2;

public interface NamingService {
	public Object lookup(String name);
	
}
