package com.varxyz.jvx330.di.example1;

public class Bar {
	public String toString() {
		return "[bar : " + hashCode() + "]";
	}
}
