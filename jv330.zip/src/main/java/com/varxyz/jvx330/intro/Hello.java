package com.varxyz.jvx330.intro;

public interface Hello {
	String sayHello(String name);
	
}
