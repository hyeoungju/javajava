package com.varxyz.jvx330.intro;

public class HelloBeanKo implements Hello{
	
	public String sayHello(String name) {
		return "안녕하세요." + name;
	}
}
