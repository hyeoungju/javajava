package com.varxyz.jvx330.intro;

public class HelloBeanEn implements Hello {
	
	@Override
	public String sayHello(String name) {
		return "Hello" + name;
	}
}
