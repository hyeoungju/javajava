package com.varxyz.jvx330.mvc.example6;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class AccTypeProvider {
	private String accCode;
	private char accHost;
}
