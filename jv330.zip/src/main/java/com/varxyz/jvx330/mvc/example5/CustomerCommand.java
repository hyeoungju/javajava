package com.varxyz.jvx330.mvc.example5;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerCommand {
	private String email; //jsp form:form태그에서 path
	private String email1;
	private String email2;
	private String passwd;
	private String name;
	private String ssn;
	private String phone;
	private String phone1;
	private String phone2;
	private String phone3;
	
}
