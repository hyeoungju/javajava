package com.varxyz.jvx330.mvc.example6;

public class Account {
	String accountNum;
	double blalance;
	char accType;
}
