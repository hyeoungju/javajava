package com.varxyz.jvx330.mvc.example6;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CheckingAccount extends Account{
	private double overAmount;

}
