package com.varxyz.banking.service;

import com.varxyz.banking.domain.Customer;

public interface CustomerService {
	public void addCustomer(Customer customer);
}
