package com.varxyz.banking.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.springframework.jdbc.IncorrectResultSetColumnCountException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.varxyz.banking.domain.Customer;

public class CustomerDao {
	private JdbcTemplate jdbcTemplate;
	
	public CustomerDao(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public void addCustomer(Customer customer) {
		String sql = "INSERT INTO Customer (userId, passwd, name, ssn, phone)"
				+ " VALUES (?, ?, ?, ?, ?)";
		jdbcTemplate.update(sql,customer.getUserId(), customer.getPasswd(),
				customer.getName(), customer.getSsn(), customer.getPhone());
	}
	
	public Customer getCustomerByUserId(String userId){
		String sql = "SELECT * FROM Customer WHERE userId=?";
		return jdbcTemplate.queryForObject(sql, new RowMapper<Customer>() { //하나만 찾는 메소드 queryForObject

			@Override
			public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
				Customer customer = new Customer(rs.getLong("cid"),
						rs.getString("userId"), rs.getString("passwd"), 
						rs.getString("name"), rs.getString("ssn"),
						rs.getString("phone"), rs.getTimestamp("regDate"));
				return customer;
			}
			
		}, userId);
	}
	
	public boolean isUser(String userId, String passwd) {
		String sql = "SELECT count(*) FROM Customer WHERE userId=? AND passwd=?";
		boolean result = true;
		int ishere = jdbcTemplate.queryForObject(sql, Integer.class, userId, passwd);
		if(ishere == 0 ) {
			result = false; 
		}
		return result;
		
	}

	public Customer getCustomerByAccountNum(String accountNum) {
		try {
			String sql = "SELECT * FROM Customer c INNER JOIN Account a ON a.customerId = c.cid"
					+ " WHERE a.accountNum=?";
			return jdbcTemplate.queryForObject(sql, new RowMapper<Customer>() { //하나만 찾는 메소드 queryForObject

				@Override
				public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
					Customer customer = new Customer(rs.getLong("cid"),
							rs.getString("userId"), rs.getString("passwd"), 
							rs.getString("name"), rs.getString("ssn"),
							rs.getString("phone"), rs.getTimestamp("regDate"));
					return customer;
				}
				
			}, accountNum);
		} catch (IncompatibleClassChangeError error) {
			return null;
		}
	}

	public boolean isValidUser(String userId) {
		String sql = "SELECT * FROM Customer WHERE userId=?";
		boolean result = true;
		try {
			int ishere = jdbcTemplate.queryForObject(sql, Integer.class, userId);
			if(ishere == 0 ) {
				result = false; 
			}			
		} catch (IncorrectResultSetColumnCountException e) {
			return result;
		}
		return result;
		
	}
	
}
