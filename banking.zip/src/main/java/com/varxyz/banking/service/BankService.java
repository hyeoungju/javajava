package com.varxyz.banking.service;

import java.util.List;

import com.varxyz.banking.domain.Account;
import com.varxyz.banking.domain.Customer;

public interface BankService {
	boolean addCustomer(Customer customer);
	
	boolean addAccounts(Account account);
	
	List<Account> getAccounts(String userId);

	boolean transfer(double money, String withdrawAccountNum, String depositAccountNum);

	boolean saveInterest(String accountNum, double interestRate);
	
	boolean getBalance(String accountNum);
	
}
