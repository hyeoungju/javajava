package com.varxyz.banking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.varxyz.banking.dao.AccountDao;
import com.varxyz.banking.domain.Account;
import com.varxyz.banking.domain.Customer;

public class TransferAccount implements BankService{
	
	
	@Autowired
	AccountDao accountDao;

	@Override
	@Transactional(rollbackFor =Exception.class)
	public boolean transfer(double money, String withdrawAccountNum, String depositAccountNum) {
		try {
			accountDao.withDraw(money,withdrawAccountNum);
			accountDao.deposit(money,depositAccountNum);
		} catch (Exception e) {
			return false;
		}
	
		return true;
	}

}
