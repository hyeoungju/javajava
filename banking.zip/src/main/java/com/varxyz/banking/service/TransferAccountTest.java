package com.varxyz.banking.service;

public class TransferAccountTest {
	
	/**
	 * transfer() 에 대해 처리할 오류나 이슈
	 * 1. 잔액부족에 대한 처리
	 * 2. 정보 노출의 이슈
	 * 
	 * 
	 */
	public static void main(String[] args) {
		TransferAccount ta = new TransferAccount();
		ta.transfer(10000, "123-456-789", "456-789-123");
	}
}
